﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface IDetectorDAO
    {

        void crear(DetectorDTO detectorDTO);

        void actualizar(DetectorDTO detectorDTO);

        void eliminar(DetectorDTO detectorDTO);

        List<DetectorDTO> consultar(DetectorDTO detectorDTO);

    }
}
