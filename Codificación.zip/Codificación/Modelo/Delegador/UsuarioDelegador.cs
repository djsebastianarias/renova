﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DTO;
using Modelo.Fachada;

namespace Modelo.Delegador
{
    public class UsuarioDelegador
    {

        private UsuarioFachada fachada = null;

        public UsuarioDelegador()
        {
            try
            {
                fachada = new UsuarioFachada();
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void crear(UsuarioDTO UsuarioDTO)
        {
            try
            {
                fachada.crear(UsuarioDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(UsuarioDTO UsuarioDTO)
        {
            try
            {
                fachada.actualizar(UsuarioDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(UsuarioDTO UsuarioDTO)
        {
            try
            {
                fachada.eliminar(UsuarioDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<UsuarioDTO> consultar(UsuarioDTO UsuarioDTO)
        {
            List<UsuarioDTO> listaUsuarios = null;
            try
            {
                listaUsuarios = fachada.consultar(UsuarioDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaUsuarios;
        }

    }
}