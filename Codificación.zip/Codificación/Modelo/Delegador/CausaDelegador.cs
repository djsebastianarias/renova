﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DTO;
using Modelo.Fachada;

namespace Modelo.Delegador
{
    public class CausaDelegador
    {

        private CausaFachada fachada = null;

        public CausaDelegador()
        {
            try
            {
                fachada = new CausaFachada();
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public int crear(CausaDTO causaDTO)
        {
            try
            {
                return fachada.crear(causaDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(CausaDTO causaDTO)
        {
            try
            {
                fachada.actualizar(causaDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(CausaDTO causaDTO)
        {
            try
            {
                fachada.eliminar(causaDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<CausaDTO> consultar(CausaDTO causaDTO)
        {
            List<CausaDTO> listaCausas = null;
            try
            {
                listaCausas = fachada.consultar(causaDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaCausas;
        }

    }
}