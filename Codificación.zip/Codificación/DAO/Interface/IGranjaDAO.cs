﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface IGranjaDAO
    {

        void crear(GranjaDTO granjaDTO);

        void actualizar(GranjaDTO granjaDTO);

        void eliminar(GranjaDTO granjaDTO);

        List<GranjaDTO> consultar(GranjaDTO granjaDTO);

    }
}
