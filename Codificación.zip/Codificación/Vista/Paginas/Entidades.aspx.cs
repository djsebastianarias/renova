﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DTO;
using Modelo.Delegador;
using Transversal;

namespace Vista.Paginas
{
    public partial class Entidades : System.Web.UI.Page
    {

        // Definir clases que se requieren para ejecución de la página
        EntidadDelegador entidadDelegador = new EntidadDelegador();

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        // Evento Click del botón Consultar
        protected void btConsultar_Click(object sender, EventArgs e)
        {
            mostrarEntidades();
        }

        // Mostrar Entidades
        private void mostrarEntidades()
        {
            EntidadDTO entidadDTO = new EntidadDTO();
            entidadDTO.Nombre = tbNombre.Text;
            List<EntidadDTO> listaEntidades = entidadDelegador.consultar(entidadDTO);
            var entidades = from e in listaEntidades
                            select new
                            {
                                codigo = e.Codigo,
                                nombre = e.Nombre,
                                estado = Constantes.Estado[e.Estado]
                            };
            gvEntidades.DataSource = entidades.ToList();
            gvEntidades.DataBind();
            gvEntidades.Visible = true;
        }

        // Evento Click del botón Guardar
        protected void btGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                EntidadDTO entidadDTO = new EntidadDTO();
                entidadDTO.Nombre = tbNombre.Text;
                entidadDTO.Estado = int.Parse(ddlEstado.SelectedValue);
                // Actualizar 
                if (hfCodigo.Value != "")
                {
                    entidadDTO.Codigo = int.Parse(hfCodigo.Value);
                    entidadDelegador.actualizar(entidadDTO);
                }
                // Guardar
                else
                {
                    entidadDelegador.crear(entidadDTO);
                }
                limpiarCampos();
                gvEntidades.Visible = false;
                ClientScript.RegisterStartupScript(this.GetType(), "mensaje", "mensaje('Entidad guardada correctamente');", true);
            }
            catch (Exception exc)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('La Entidad ya se encuentra registrada');", true);
            }
        }

        // Paginación
        protected void gvEntidades_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvEntidades.PageIndex = e.NewPageIndex;
            mostrarEntidades();
        }

        // Opciones
        protected void gvEntidades_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int index = Convert.ToInt32(e.CommandArgument);
            // Editar 
            if (e.CommandName.Equals("editar"))
            {
                hfCodigo.Value = gvEntidades.DataKeys[index].Value.ToString();
                EntidadDTO entidadDTO = new EntidadDTO();
                entidadDTO.Codigo = int.Parse(hfCodigo.Value);
                entidadDTO = entidadDelegador.consultar(entidadDTO)[0];
                tbNombre.Text = entidadDTO.Nombre;
                ddlEstado.SelectedValue = entidadDTO.Estado.ToString();
            }
            // Eliminar
            else if (e.CommandName.Equals("eliminar"))
            {
                hfCodigo.Value = gvEntidades.DataKeys[index].Value.ToString();
                mpeEliminar.Enabled = true;
                mpeEliminar.Show();
            }
        }

        // Evento Click del botón Delete
        protected void btDelete_Click(object sender, EventArgs e)
        {
            try
            {
                EntidadDTO entidadDTO = new EntidadDTO();
                entidadDTO.Codigo = int.Parse(hfCodigo.Value);
                entidadDelegador.eliminar(entidadDTO);
                gvEntidades.Visible = false;
                ClientScript.RegisterStartupScript(this.GetType(), "mensaje", "mensaje('Entidad eliminada correctamente');", true);
            }
            catch (Exception exc)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('No se puede eliminar esta Entidad porque tiene productos asociados');", true);
            }
            finally
            {
                limpiarCampos();
            }
        }

        // Evento Click del botón Cancelar eliminar
        protected void btCancelarEliminar_Click(object sender, EventArgs e)
        {
            limpiarCampos();
        }

        // Limpiar Campos
        private void limpiarCampos()
        {
            tbNombre.Text = ddlEstado.SelectedValue = hfCodigo.Value = "";
            mpeEliminar.Enabled = gvEntidades.Visible = false;
            mpeEliminar.Hide();
        }

        // Evento Click botón Cancelar
        protected void btCancelar_Click(object sender, EventArgs e)
        {
            limpiarCampos();
        }

    }
}