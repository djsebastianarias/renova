﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using DAO.Interface;
using DTO;

namespace DAO.Implementacion.MySql
{
    public class TipologiaMySqlDAO : ITipologiaDAO
    {

        private MySqlTransaction transaccion;

        public TipologiaMySqlDAO(MySqlTransaction transaccion)
        {
            this.transaccion = transaccion;
        }

        public void crear(TipologiaDTO tipologiaDTO)
        {
            try
            {
                String sentenciaSQL = "INSERT INTO bsb_tipologia(NV_NOMBRE, NM_PRODUCTO, NM_ESTADO) VALUES(@NV_NOMBRE, @NM_CODIGO_PRODUCTO, @NM_ESTADO)";
                using (MySqlCommand comandoSQL = new MySqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NV_NOMBRE", MySqlDbType.VarChar).Value = tipologiaDTO.Nombre;
                    comandoSQL.Parameters.Add("@NM_CODIGO_PRODUCTO", MySqlDbType.Int32).Value = tipologiaDTO.Producto.Codigo;
                    comandoSQL.Parameters.Add("@NM_ESTADO", MySqlDbType.Int24).Value = tipologiaDTO.Estado;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(TipologiaDTO tipologiaDTO)
        {
            try
            {
                String sentenciaSQL = "UPDATE bsb_tipologia SET NV_NOMBRE = @NV_NOMBRE, NM_PRODUCTO = @NM_CODIGO_PRODUCTO, NM_ESTADO = @NM_ESTADO WHERE NM_CODIGO = @NM_CODIGO";
                using (MySqlCommand comandoSQL = new MySqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NV_NOMBRE", MySqlDbType.VarChar).Value = tipologiaDTO.Nombre;
                    comandoSQL.Parameters.Add("@NM_CODIGO_PRODUCTO", MySqlDbType.Int32).Value = tipologiaDTO.Producto.Codigo;
                    comandoSQL.Parameters.Add("@NM_ESTADO", MySqlDbType.Int24).Value = tipologiaDTO.Estado;
                    comandoSQL.Parameters.Add("@NM_CODIGO", MySqlDbType.Int32).Value = tipologiaDTO.Codigo;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(TipologiaDTO tipologiaDTO)
        {
            try
            {
                String sentenciaSQL = "DELETE FROM bsb_tipologia WHERE NM_CODIGO = @NM_CODIGO";
                using (MySqlCommand comandoSQL = new MySqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NM_CODIGO", MySqlDbType.Int32).Value = tipologiaDTO.Codigo;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<TipologiaDTO> consultar(TipologiaDTO tipologiaDTO)
        {
            List<TipologiaDTO> listaTipologia = new List<TipologiaDTO>();
            try
            {
                String sentenciaSQL = "SELECT T.NM_CODIGO, T.NV_NOMBRE, T.NM_ESTADO, P.NM_CODIGO, P.NV_NOMBRE  " +
                                      "FROM bsb_tipologia T " +
                                      "INNER JOIN bsb_producto P ON P.NM_CODIGO = T.NM_PRODUCTO WHERE 1";
                using (MySqlCommand comandoSQL = new MySqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Consultar por codigo
                    if (tipologiaDTO.Codigo != 0)
                    {
                        sentenciaSQL += " AND T.NM_CODIGO = @NM_CODIGO";
                        comandoSQL.Parameters.Add("@NM_CODIGO", MySqlDbType.Int32).Value = tipologiaDTO.Codigo;
                    }
                    // Consultar por nombre
                    if (tipologiaDTO.Nombre != null && tipologiaDTO.Nombre != "")
                    {
                        sentenciaSQL += " AND T.NV_NOMBRE LIKE @NV_NOMBRE";
                        comandoSQL.Parameters.Add("@NV_NOMBRE", MySqlDbType.VarChar).Value = "%" + tipologiaDTO.Nombre + "%";
                    }
                    // Consultar por producto
                    if (tipologiaDTO.Producto != null && tipologiaDTO.Producto.Codigo != 0)
                    {
                        sentenciaSQL += " AND T.NM_PRODUCTO = @NM_CODIGO_PRODUCTO";
                        comandoSQL.Parameters.Add("@NM_CODIGO_PRODUCTO", MySqlDbType.Int32).Value = tipologiaDTO.Producto.Codigo;
                    }
                    sentenciaSQL += " ORDER BY T.NM_PRODUCTO, T.NV_NOMBRE";
                    comandoSQL.CommandText = sentenciaSQL;
                    using (MySqlDataReader cursorDatos = comandoSQL.ExecuteReader())
                    {
                        TipologiaDTO tipologiaDTOTmp = null;
                        ProductoDTO productoDTOTmp = null;
                        while (cursorDatos.Read())
                        {
                            tipologiaDTOTmp = new TipologiaDTO();
                            tipologiaDTOTmp.Codigo = cursorDatos.GetInt32(0);
                            tipologiaDTOTmp.Nombre = cursorDatos.GetString(1);
                            tipologiaDTOTmp.Estado = (int)cursorDatos.GetDecimal(2);
                            productoDTOTmp = new ProductoDTO();
                            productoDTOTmp.Codigo = cursorDatos.GetInt32(3);
                            productoDTOTmp.Nombre = cursorDatos.GetString(4);
                            tipologiaDTOTmp.Producto = productoDTOTmp;
                            listaTipologia.Add(tipologiaDTOTmp);
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaTipologia;
        }

    }
}