﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAO.Interface;
using DTO;
using DAO.DAOFactory;

namespace Modelo.Negocio
{
    public class ProductoNegocio
    {

        public void crear(ProductoDTO productoDTO, DAOFactory dao)
        {
            try
            {
                IProductoDAO productoDAO = dao.getProductoDAO();
                productoDAO.crear(productoDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(ProductoDTO productoDTO, DAOFactory dao)
        {
            try
            {
                IProductoDAO productoDAO = dao.getProductoDAO();
                productoDAO.actualizar(productoDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(ProductoDTO productoDTO, DAOFactory dao)
        {
            try
            {
                IProductoDAO productoDAO = dao.getProductoDAO();
                productoDAO.eliminar(productoDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<ProductoDTO> consultar(ProductoDTO productoDTO, DAOFactory dao)
        {
            List<ProductoDTO> listaRetorno = null;
            try
            {
                IProductoDAO productoDAO = dao.getProductoDAO();
                listaRetorno = productoDAO.consultar(productoDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaRetorno;
        }

    }
}
