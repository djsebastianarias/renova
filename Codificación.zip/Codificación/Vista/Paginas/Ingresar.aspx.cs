﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using DTO;
using Modelo.Delegador;
using Transversal;

namespace Vista.Paginas
{
    public partial class Ingresar : System.Web.UI.Page
    {

        // Definir clases que se requieren para ejecución de la página
        UsuarioDelegador usuarioDelegador = new UsuarioDelegador();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        // Evento Click del botón Ingresar
        protected void btIngresar_Click(object sender, EventArgs e)
        {
            UsuarioDTO usuarioDTO = new UsuarioDTO();
            usuarioDTO.Email = tbEmail.Text;
            List<UsuarioDTO> listaUsuario = usuarioDelegador.consultar(usuarioDTO);
            
            // Validar que el usuario existe
            if (listaUsuario.Count > 0)
            {
                usuarioDTO = listaUsuario[0];
                // Validar que el usuario se encuentra Activo (1)
                if (usuarioDTO.Estado == 1)
                {
                    // Validar password
                    if (tbPassword.Text.Equals(usuarioDTO.Password))
                    {
                        // Datos de la Sesión
                        Session["usuario"] = usuarioDTO.Id.ToString();
                        Session["nombre"] = usuarioDTO.Nombre;
                        // Redireccionar a página de Administrador
                        Server.Transfer("Entidades.aspx");
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('La contraseña es incorrecta. Para recuperar su clave ingrese por la opción Olvidé mis datos');", true);
                    }
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('El usuario se encuentra inactivo');", true);
                }
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('El usuario no se encuentra registrado');", true);
            }
        }

        // Evento Click del botón Guardar clave
        protected void btGuardarClave_Click(object sender, EventArgs e)
        {
            try
            {
                UsuarioDTO usuarioDTO = new UsuarioDTO();
                usuarioDTO.Email = tbEmailClave.Text;
                List<UsuarioDTO> listaUsuario = usuarioDelegador.consultar(usuarioDTO);

                // Validar que el usuario existe
                if (listaUsuario.Count > 0)
                {
                    usuarioDTO = listaUsuario[0];
                    // Validar password
                    if (usuarioDTO.Password.Equals(""))
                    {
                        string pass = "";
                        // Generar contraseña con Membership
                        usuarioDTO.Password = pass = Membership.GeneratePassword(8, 3);
                        usuarioDelegador.actualizar(usuarioDTO);
                        usuarioDTO.Password = pass;
                    }
                    // Enviar correo
                    UtilEmail.recuperarPassword(usuarioDTO);
                    ClientScript.RegisterStartupScript(this.GetType(), "mensaje", "mensaje('Se ha enviado un correo electrónico con las instrucciones para recuperar la contraseña');", true);
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('El usuario no se encuentra registrado');", true);
                }
            }
            catch (Exception exc)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('Error al enviar correo. Verificar la configuración');", true);
            }
        }

    }
}