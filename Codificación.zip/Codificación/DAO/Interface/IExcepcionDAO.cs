﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface IExcepcionDAO
    {

        void crear(ExcepcionDTO excepcionDTO);

        void actualizar(ExcepcionDTO excepcionDTO);

        void eliminar(ExcepcionDTO excepcionDTO);

        List<ExcepcionDTO> consultar(ExcepcionDTO excepcionDTO);

    }
}