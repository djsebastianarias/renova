﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface ICorralDAO
    {

        void crear(CorralDTO corralDTO);

        void actualizar(CorralDTO corralDTO);

        void eliminar(CorralDTO corralDTO);

        List<CorralDTO> consultar(CorralDTO corralDTO);

    }
}
