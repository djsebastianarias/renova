﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DTO
{
    public class PasoDTO
    {

        private int codigo;

        public int Codigo
        {
            get { return codigo; }
            set { codigo = value; }
        }

        private CausaDTO causa;

        public CausaDTO Causa
        {
            get { return causa; }
            set { causa = value; }
        }

        private string descripcion;

        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }
        }

        private string escala;

        public string Escala
        {
            get { return escala; }
            set { escala = value; }
        }

        private string segundoNivel;

        public string SegundoNivel
        {
            get { return segundoNivel; }
            set { segundoNivel = value; }
        }

        private string recomendaciones;

        public string Recomendaciones
        {
            get { return recomendaciones; }
            set { recomendaciones = value; }
        }

    }
}
