﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAO.Interface;
using DTO;
using DAO.DAOFactory;

namespace Modelo.Negocio
{
    public class CausaNegocio
    {

        public int crear(CausaDTO causaDTO, DAOFactory dao)
        {
            try
            {
                ICausaDAO causaDAO = dao.getCausaDAO();
                return causaDAO.crear(causaDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(CausaDTO causaDTO, DAOFactory dao)
        {
            try
            {
                ICausaDAO causaDAO = dao.getCausaDAO();
                causaDAO.actualizar(causaDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(CausaDTO causaDTO, DAOFactory dao)
        {
            try
            {
                ICausaDAO causaDAO = dao.getCausaDAO();
                causaDAO.eliminar(causaDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<CausaDTO> consultar(CausaDTO causaDTO, DAOFactory dao)
        {
            List<CausaDTO> listaRetorno = null;
            try
            {
                ICausaDAO causaDAO = dao.getCausaDAO();
                listaRetorno = causaDAO.consultar(causaDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaRetorno;
        }

    }
}
