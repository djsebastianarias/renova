﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using DAO.Interface;
using DTO;

namespace DAO.Implementacion.SQLServer
{
    public class EntidadSQLServerDAO : IEntidadDAO
    {

        private SqlTransaction transaccion;

        public EntidadSQLServerDAO(SqlTransaction transaccion)
        {
            this.transaccion = transaccion;
        }

        public void crear(EntidadDTO entidadDTO)
        {
            try
            {
                String sentenciaSQL = "INSERT INTO bsb_entidad(NV_NOMBRE, NM_ESTADO) VALUES(@NV_NOMBRE, @NM_ESTADO)";
                using (SqlCommand comandoSQL = new SqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NV_NOMBRE", SqlDbType.VarChar).Value = entidadDTO.Nombre;
                    comandoSQL.Parameters.Add("@NM_ESTADO", SqlDbType.Int).Value = entidadDTO.Estado;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(EntidadDTO entidadDTO)
        {
            try
            {
                String sentenciaSQL = "UPDATE bsb_entidad SET NV_NOMBRE = @NV_NOMBRE, NM_ESTADO = @NM_ESTADO WHERE NM_CODIGO = @NM_CODIGO";
                using (SqlCommand comandoSQL = new SqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NV_NOMBRE", SqlDbType.VarChar).Value = entidadDTO.Nombre;
                    comandoSQL.Parameters.Add("@NM_ESTADO", SqlDbType.Int).Value = entidadDTO.Estado;
                    comandoSQL.Parameters.Add("@NM_CODIGO", SqlDbType.Int).Value = entidadDTO.Codigo;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(EntidadDTO entidadDTO)
        {
            try
            {
                String sentenciaSQL = "DELETE FROM bsb_entidad WHERE NM_CODIGO = @NM_CODIGO";
                using (SqlCommand comandoSQL = new SqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NM_CODIGO", SqlDbType.Int).Value = entidadDTO.Codigo;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<EntidadDTO> consultar(EntidadDTO entidadDTO)
        {
            List<EntidadDTO> listaEntidad = new List<EntidadDTO>();
            try
            {
                String sentenciaSQL = "SELECT NM_CODIGO, NV_NOMBRE, NM_ESTADO FROM bsb_entidad WHERE NM_CODIGO > 0";
                using (SqlCommand comandoSQL = new SqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Consultar por codigo
                    if (entidadDTO.Codigo != 0)
                    {
                        sentenciaSQL += " AND NM_CODIGO = @NM_CODIGO";
                        comandoSQL.Parameters.Add("@NM_CODIGO", SqlDbType.Int).Value = entidadDTO.Codigo;
                    }
                    // Consultar por nombre
                    if (entidadDTO.Nombre != null && entidadDTO.Nombre != "")
                    {
                        sentenciaSQL += " AND NV_NOMBRE LIKE @NV_NOMBRE";
                        comandoSQL.Parameters.Add("@NV_NOMBRE", SqlDbType.VarChar).Value = "%" + entidadDTO.Nombre + "%";
                    }
                    sentenciaSQL += " ORDER BY NV_NOMBRE";
                    comandoSQL.CommandText = sentenciaSQL;
                    using (SqlDataReader cursorDatos = comandoSQL.ExecuteReader())
                    {
                        EntidadDTO entidadDTOTmp = null;
                        while (cursorDatos.Read())
                        {
                            entidadDTOTmp = new EntidadDTO();
                            entidadDTOTmp.Codigo = cursorDatos.GetInt32(0);
                            entidadDTOTmp.Nombre = cursorDatos.GetString(1);
                            entidadDTOTmp.Estado = (int)cursorDatos.GetDecimal(2);
                            listaEntidad.Add(entidadDTOTmp);
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaEntidad;
        }

    }
}