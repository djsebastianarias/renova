﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface IAdminEstacionDAO
    {

        void crear(AdminEstacionDTO adminEstacionDTO);

        void actualizar(AdminEstacionDTO adminEstacionDTO);

        void eliminar(AdminEstacionDTO adminEstacionDTO);

        List<AdminEstacionDTO> consultar(AdminEstacionDTO adminEstacionDTO);

    }
}