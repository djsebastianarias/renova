﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface IClasificacionDAO
    {

        void crear(ClasificacionDTO clasificacionDTO);

        void actualizar(ClasificacionDTO clasificacionDTO);

        void eliminar(ClasificacionDTO clasificacionDTO);

        List<ClasificacionDTO> consultar(ClasificacionDTO clasificacionDTO);
        List<ClasificacionDTO> notificacion(ClasificacionDTO clasificacionDTO);

    }
}