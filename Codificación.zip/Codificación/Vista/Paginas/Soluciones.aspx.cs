﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DTO;
using Modelo.Delegador;

namespace Vista.Paginas
{
    public partial class Soluciones : System.Web.UI.Page
    {

        // Definir clases que se requieren para ejecución de la página
        ProductoDelegador productoDelegador = new ProductoDelegador();
        TipologiaDelegador tipologiaDelegador = new TipologiaDelegador();
        CausaDelegador causaDelegador = new CausaDelegador();
        PasoDelegador pasoDelegador = new PasoDelegador();

        protected void Page_Load(object sender, EventArgs e)
        {
            // Ejecutar al cargar la página por primera vez
            if (!IsPostBack)
            {
                mostrarProductos();
                mostrarTipologias();
                mostrarCausas();
            }
        }

        // Mostrar Productos
        private void mostrarProductos()
        {
            List<ProductoDTO> listaProductos = productoDelegador.consultar(new ProductoDTO());
            var productos = from p in listaProductos
                            select new
                            {
                                codigo = p.Codigo,
                                nombre = p.Nombre
                            };
            ddlProducto.DataSource = productos.ToList();
            ddlProducto.DataBind();
            ListItem item = new ListItem("Seleccione", "");
            ddlProducto.Items.Insert(0, item);
        }

        // Mostrar Tipologias
        private void mostrarTipologias()
        {
            List<TipologiaDTO> listaTipologias = tipologiaDelegador.consultar(new TipologiaDTO());
            var tipologias = from t in listaTipologias
                             select new
                             {
                                 codigo = t.Codigo,
                                 nombre = t.Nombre
                             };
            ddlTipologia.DataSource = tipologias.ToList();
            ddlTipologia.DataBind();
            ListItem item = new ListItem("Seleccione", "");
            ddlTipologia.Items.Insert(0, item);
        }

        // Mostrar Causas
        private void mostrarCausas()
        {
            List<CausaDTO> listaCausas = causaDelegador.consultar(new CausaDTO());
            var causas = from c in listaCausas
                         select new
                         {
                             codigo = c.Codigo,
                             nombre = c.Nombre
                         };
            ddlCausa.DataSource = causas.ToList();
            ddlCausa.DataBind();
            ListItem item = new ListItem("Seleccione", "");
            ddlCausa.Items.Insert(0, item);
        }

        // Evento Click del botón Consultar Soluciones
        protected void btConsultar_Click(object sender, EventArgs e)
        {
            try
            {
                DivResultados.Visible = gvPasos.Visible = false;
                gvResultados.SelectedIndex = -1;
                CausaDTO causaDTO = new CausaDTO();
                TipologiaDTO tipologiaDTO = new TipologiaDTO();

                // Filtros
                if (ddlCausa.SelectedValue != "")
                {
                    causaDTO.Codigo = int.Parse(ddlCausa.SelectedValue);
                    causaDTO.Tipologia = new TipologiaDTO();
                }
                else if (ddlTipologia.SelectedValue != "")
                {
                    tipologiaDTO.Codigo = int.Parse(ddlTipologia.SelectedValue);
                    causaDTO.Tipologia = tipologiaDTO;
                }
                else if (ddlProducto.SelectedValue != "")
                {
                    ProductoDTO productoDTO = new ProductoDTO();
                    productoDTO.Codigo = int.Parse(ddlProducto.SelectedValue);
                    tipologiaDTO.Producto = productoDTO;
                    causaDTO.Tipologia = tipologiaDTO;
                }

                // Mostrar resultados
                List<CausaDTO> listaCausas = causaDelegador.consultar(causaDTO);
                var causas = from c in listaCausas
                             select new
                             {
                                 codigo = c.Codigo,
                                 producto = c.Tipologia.Producto.Nombre,
                                 tipologia = c.Tipologia.Nombre,
                                 causa = c.Nombre
                             };
                gvResultados.DataSource = causas.ToList();
                gvResultados.DataBind();
                DivResultados.Visible = true;
            }
            catch (Exception exc)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('Error al consultar la solución');", true);
            }
        }

        // Ver pasos
        protected void gvResultados_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                CausaDTO causaDTO = new CausaDTO();
                causaDTO.Codigo = int.Parse(gvResultados.SelectedValue.ToString());
                PasoDTO pasoDTO = new PasoDTO();
                pasoDTO.Causa = causaDTO;
                List<PasoDTO> listaPaso = pasoDelegador.consultar(pasoDTO);
                var pasos = from p in listaPaso
                            select new
                            {
                                descripcion = p.Descripcion,
                                escala = p.Escala,
                                nivel2 = p.SegundoNivel,
                                recomendaciones = p.Recomendaciones
                            };
                gvPasos.DataSource = pasos.ToList();
                gvPasos.DataBind();
                gvPasos.Visible = true;
            }
            catch (Exception exc)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('Error al consultar el paso a paso');", true);
            }
        }

    }
}