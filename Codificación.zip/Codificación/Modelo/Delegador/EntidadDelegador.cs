﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DTO;
using Modelo.Fachada;

namespace Modelo.Delegador
{
    public class EntidadDelegador
    {

        private EntidadFachada fachada = null;

        public EntidadDelegador()
        {
            try
            {
                fachada = new EntidadFachada();
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void crear(EntidadDTO entidadDTO)
        {
            try
            {
                fachada.crear(entidadDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(EntidadDTO entidadDTO)
        {
            try
            {
                fachada.actualizar(entidadDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(EntidadDTO entidadDTO)
        {
            try
            {
                fachada.eliminar(entidadDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<EntidadDTO> consultar(EntidadDTO entidadDTO)
        {
            List<EntidadDTO> listaEntidades = null;
            try
            {
                listaEntidades = fachada.consultar(entidadDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaEntidades;
        }

    }
}