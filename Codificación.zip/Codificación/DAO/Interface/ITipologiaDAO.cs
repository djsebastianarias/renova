﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DTO;

namespace DAO.Interface
{
    public interface ITipologiaDAO
    {

        void crear(TipologiaDTO tipologiaDTO);

        void actualizar(TipologiaDTO tipologiaDTO);

        void eliminar(TipologiaDTO tipologiaDTO);

        List<TipologiaDTO> consultar(TipologiaDTO tipologiaDTO);

    }
}