﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAO.Interface;
using DTO;
using DAO.DAOFactory;

namespace Modelo.Negocio
{
    public class EntidadNegocio
    {

        public void crear(EntidadDTO entidadDTO, DAOFactory dao)
        {
            try
            {
                IEntidadDAO entidadDAO = dao.getEntidadDAO();
                entidadDAO.crear(entidadDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(EntidadDTO entidadDTO, DAOFactory dao)
        {
            try
            {
                IEntidadDAO entidadDAO = dao.getEntidadDAO();
                entidadDAO.actualizar(entidadDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(EntidadDTO entidadDTO, DAOFactory dao)
        {
            try
            {
                IEntidadDAO entidadDAO = dao.getEntidadDAO();
                entidadDAO.eliminar(entidadDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<EntidadDTO> consultar(EntidadDTO entidadDTO, DAOFactory dao)
        {
            List<EntidadDTO> listaRetorno = null;
            try
            {
                IEntidadDAO entidadDAO = dao.getEntidadDAO();
                listaRetorno = entidadDAO.consultar(entidadDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaRetorno;
        }

    }
}
