﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DTO;

namespace DAO.Interface
{
    public interface IProductoDAO
    {

        void crear(ProductoDTO productoDTO);

        void actualizar(ProductoDTO productoDTO);

        void eliminar(ProductoDTO productoDTO);

        List<ProductoDTO> consultar(ProductoDTO productoDTO);

    }
}