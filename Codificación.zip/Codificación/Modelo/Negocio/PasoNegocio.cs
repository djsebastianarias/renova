﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAO.Interface;
using DTO;
using DAO.DAOFactory;

namespace Modelo.Negocio
{
    public class PasoNegocio
    {

        public void crear(PasoDTO pasoDTO, DAOFactory dao)
        {
            try
            {
                IPasoDAO pasoDAO = dao.getPasoDAO();
                pasoDAO.crear(pasoDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(PasoDTO pasoDTO, DAOFactory dao)
        {
            try
            {
                IPasoDAO pasoDAO = dao.getPasoDAO();
                pasoDAO.actualizar(pasoDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(PasoDTO pasoDTO, DAOFactory dao)
        {
            try
            {
                IPasoDAO pasoDAO = dao.getPasoDAO();
                pasoDAO.eliminar(pasoDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<PasoDTO> consultar(PasoDTO pasoDTO, DAOFactory dao)
        {
            List<PasoDTO> listaRetorno = null;
            try
            {
                IPasoDAO pasoDAO = dao.getPasoDAO();
                listaRetorno = pasoDAO.consultar(pasoDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaRetorno;
        }

    }
}
