﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DTO;

namespace DAO.Interface
{    
    public interface IUsuarioDAO
    {

        void crear(UsuarioDTO usuarioDTO);

        void actualizar(UsuarioDTO usuarioDTO);

        void eliminar(UsuarioDTO usuarioDTO);

        List<UsuarioDTO> consultar(UsuarioDTO usuarioDTO);

    }
}
