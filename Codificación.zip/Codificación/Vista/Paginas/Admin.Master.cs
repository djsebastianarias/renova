﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DTO;
using Modelo.Delegador;

namespace Vista.Paginas
{
    public partial class Admin : System.Web.UI.MasterPage
    {

        UsuarioDelegador usuarioDelegador = new UsuarioDelegador();

        protected void Page_Load(object sender, EventArgs e)
        {
            // Ejecutar al cargar la página por primera vez
            if (!IsPostBack)
            {
                // Obtener datos de la Sesión
                string usuario = (string)(Session["usuario"]);
                string nombre = (string)(Session["nombre"]);
                if (usuario == null || usuario == "0")
                {
                    Server.Transfer("Ingresar.aspx");
                }
                else
                {
                    lbUsuario.Text = nombre;
                }
            }
        }

    }
}