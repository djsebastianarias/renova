﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface IAlimentacionDAO
    {

        void crear(AlimentacionDTO alimentacionDTO);

        void actualizar(AlimentacionDTO alimentacionDTO);

        void eliminar(AlimentacionDTO alimentacionDTO);

        List<AlimentacionDTO> consultar(AlimentacionDTO alimentacionDTO);
        List<AlimentacionDTO> notificacion(AlimentacionDTO alimentacionDTO);
        List<AlimentacionDTO> consumoMensual(AlimentacionDTO alimentacionDTO);
        List<AlimentacionDTO> consumoEstacion(AlimentacionDTO alimentacionDTO);
        List<AlimentacionDTO> consumoGestacion(AlimentacionDTO alimentacionDTO);
        List<AlimentacionDTO> porcionIncompleta(AlimentacionDTO alimentacionDTO);

    }
}