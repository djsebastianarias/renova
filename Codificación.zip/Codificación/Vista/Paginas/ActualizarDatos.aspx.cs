﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DTO;
using Modelo.Delegador;

namespace Vista.Paginas
{
    public partial class ActualizarDatos : System.Web.UI.Page
    {

        // Definir clases que se requieren para ejecución de la página
        UsuarioDelegador usuarioDelegador = new UsuarioDelegador();

        protected void Page_Load(object sender, EventArgs e)
        {
            // Ejecutar al cargar la página por primera vez
            if (!IsPostBack)
            {
                // Datos del Usuario
                UsuarioDTO usuarioDTO = new UsuarioDTO();
                usuarioDTO.Id = (string)Session["usuario"];
                usuarioDTO = usuarioDelegador.consultar(usuarioDTO)[0];
                lbCc.Text = usuarioDTO.Id;
                lbNombre.Text = usuarioDTO.Nombre;
                tbEmail.Text = usuarioDTO.Email;
            }
        }

        // Obtener datos del Usuario
        private UsuarioDTO getDatos()
        {
            UsuarioDTO usuarioDTO = new UsuarioDTO();
            usuarioDTO.Id = (string)Session["usuario"];
            usuarioDTO = usuarioDelegador.consultar(usuarioDTO)[0];
            usuarioDTO.Email = tbEmail.Text;
            if (tbPass.Text != "")
            {
                usuarioDTO.Password = tbPass.Text;
            }
            return usuarioDTO;
        }

        // Evento Click del botón Aceptar
        protected void btAceptar_Click(object sender, EventArgs e)
        {
            try
            {
                // Actualizar datos del Usuario
                UsuarioDTO usuarioDTO = getDatos();
                usuarioDelegador.actualizar(usuarioDTO);
                ClientScript.RegisterStartupScript(this.GetType(), "mensaje", "mensaje('Datos actualizados correctamente');", true);
            }
            catch (Exception exc)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('Error al actualizar los datos');", true);
            }
        }

    }
}