﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using DAO.Interface;
using DTO;

namespace DAO.Implementacion.SQLServer
{
    public class ProductoSQLServerDAO : IProductoDAO
    {

        private SqlTransaction transaccion;

        public ProductoSQLServerDAO(SqlTransaction transaccion)
        {
            this.transaccion = transaccion;
        }

        public void crear(ProductoDTO productoDTO)
        {
            try
            {
                String sentenciaSQL = "INSERT INTO bsb_producto(NV_NOMBRE, NM_ENTIDAD, NM_ESTADO) VALUES(@NV_NOMBRE, @NM_CODIGO_ENTIDAD, @NM_ESTADO)";
                using (SqlCommand comandoSQL = new SqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NV_NOMBRE", SqlDbType.VarChar).Value = productoDTO.Nombre;
                    comandoSQL.Parameters.Add("@NM_CODIGO_ENTIDAD", SqlDbType.Int).Value = productoDTO.Entidad.Codigo;
                    comandoSQL.Parameters.Add("@NM_ESTADO", SqlDbType.Int).Value = productoDTO.Estado;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(ProductoDTO productoDTO)
        {
            try
            {
                String sentenciaSQL = "UPDATE bsb_producto SET NV_NOMBRE = @NV_NOMBRE, NM_ENTIDAD = @NM_CODIGO_ENTIDAD, NM_ESTADO = @NM_ESTADO WHERE NM_CODIGO = @NM_CODIGO";
                using (SqlCommand comandoSQL = new SqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NV_NOMBRE", SqlDbType.VarChar).Value = productoDTO.Nombre;
                    comandoSQL.Parameters.Add("@NM_CODIGO_ENTIDAD", SqlDbType.Int).Value = productoDTO.Entidad.Codigo;
                    comandoSQL.Parameters.Add("@NM_ESTADO", SqlDbType.Int).Value = productoDTO.Estado;
                    comandoSQL.Parameters.Add("@NM_CODIGO", SqlDbType.Int).Value = productoDTO.Codigo;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(ProductoDTO productoDTO)
        {
            try
            {
                String sentenciaSQL = "DELETE FROM bsb_producto WHERE NM_CODIGO = @NM_CODIGO";
                using (SqlCommand comandoSQL = new SqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NM_CODIGO", SqlDbType.Int).Value = productoDTO.Codigo;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<ProductoDTO> consultar(ProductoDTO productoDTO)
        {
            List<ProductoDTO> listaProducto = new List<ProductoDTO>();
            try
            {
                String sentenciaSQL = "SELECT P.NM_CODIGO, P.NV_NOMBRE, P.NM_ESTADO, E.NM_CODIGO, E.NV_NOMBRE " +
                                      "FROM bsb_producto P " +
                                      "INNER JOIN bsb_entidad E ON E.NM_CODIGO = P.NM_ENTIDAD WHERE P.NM_CODIGO > 0";
                using (SqlCommand comandoSQL = new SqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Consultar por codigo
                    if (productoDTO.Codigo != 0)
                    {
                        sentenciaSQL += " AND P.NM_CODIGO = @NM_CODIGO";
                        comandoSQL.Parameters.Add("@NM_CODIGO", SqlDbType.Int).Value = productoDTO.Codigo;
                    }
                    // Consultar por nombre
                    if (productoDTO.Nombre != null && productoDTO.Nombre != "")
                    {
                        sentenciaSQL += " AND P.NV_NOMBRE LIKE @NV_NOMBRE";
                        comandoSQL.Parameters.Add("@NV_NOMBRE", SqlDbType.VarChar).Value = "%" + productoDTO.Nombre + "%";
                    }
                    // Consultar por entidad
                    if (productoDTO.Entidad != null && productoDTO.Entidad.Codigo != 0)
                    {
                        sentenciaSQL += " AND P.NM_ENTIDAD = @NM_CODIGO_ENTIDAD";
                        comandoSQL.Parameters.Add("@NM_CODIGO_ENTIDAD", SqlDbType.Int).Value = productoDTO.Entidad.Codigo;
                    }
                    sentenciaSQL += " ORDER BY P.NM_ENTIDAD, P.NV_NOMBRE";
                    comandoSQL.CommandText = sentenciaSQL;
                    using (SqlDataReader cursorDatos = comandoSQL.ExecuteReader())
                    {
                        ProductoDTO productoDTOTmp = null;
                        EntidadDTO entidadDTOTmp = null;
                        while (cursorDatos.Read())
                        {
                            productoDTOTmp = new ProductoDTO();
                            productoDTOTmp.Codigo = cursorDatos.GetInt32(0);
                            productoDTOTmp.Nombre = cursorDatos.GetString(1);
                            productoDTOTmp.Estado = (int)cursorDatos.GetDecimal(2);
                            entidadDTOTmp = new EntidadDTO();
                            entidadDTOTmp.Codigo = cursorDatos.GetInt32(3);
                            entidadDTOTmp.Nombre = cursorDatos.GetString(4);
                            productoDTOTmp.Entidad = entidadDTOTmp;
                            listaProducto.Add(productoDTOTmp);
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaProducto;
        }

    }
}