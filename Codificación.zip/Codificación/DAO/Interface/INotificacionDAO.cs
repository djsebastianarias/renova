﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface INotificacionDAO
    {

        void crear(NotificacionDTO notificacionDTO);

        void actualizar(NotificacionDTO notificacionDTO);

        void eliminar(NotificacionDTO notificacionDTO);

        List<NotificacionDTO> consultar(NotificacionDTO notificacionDTO);

    }
}