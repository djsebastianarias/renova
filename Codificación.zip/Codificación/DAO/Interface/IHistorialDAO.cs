﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface IHistorialDAO
    {

        void crear(HistorialDTO historialDTO);

        void actualizar(HistorialDTO historialDTO);

        void eliminar(HistorialDTO historialDTO);

        List<HistorialDTO> consultar(HistorialDTO historialDTO);

    }
}