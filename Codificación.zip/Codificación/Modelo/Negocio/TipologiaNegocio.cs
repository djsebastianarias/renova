﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAO.Interface;
using DTO;
using DAO.DAOFactory;

namespace Modelo.Negocio
{
    public class TipologiaNegocio
    {

        public void crear(TipologiaDTO tipologiaDTO, DAOFactory dao)
        {
            try
            {
                ITipologiaDAO tipologiaDAO = dao.getTipologiaDAO();
                tipologiaDAO.crear(tipologiaDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(TipologiaDTO tipologiaDTO, DAOFactory dao)
        {
            try
            {
                ITipologiaDAO tipologiaDAO = dao.getTipologiaDAO();
                tipologiaDAO.actualizar(tipologiaDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(TipologiaDTO tipologiaDTO, DAOFactory dao)
        {
            try
            {
                ITipologiaDAO tipologiaDAO = dao.getTipologiaDAO();
                tipologiaDAO.eliminar(tipologiaDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<TipologiaDTO> consultar(TipologiaDTO tipologiaDTO, DAOFactory dao)
        {
            List<TipologiaDTO> listaRetorno = null;
            try
            {
                ITipologiaDAO tipologiaDAO = dao.getTipologiaDAO();
                listaRetorno = tipologiaDAO.consultar(tipologiaDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaRetorno;
        }

    }
}
