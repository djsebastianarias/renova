﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DTO;

namespace DAO.Interface
{
    public interface IEntidadDAO
    {

        void crear(EntidadDTO entidadDTO);

        void actualizar(EntidadDTO entidadDTO);

        void eliminar(EntidadDTO entidadDTO);

        List<EntidadDTO> consultar(EntidadDTO entidadDTO);

    }
}