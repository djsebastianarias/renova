﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DTO;

namespace DAO.Interface
{
    public interface IPasoDAO
    {

        void crear(PasoDTO pasoDTO);

        void actualizar(PasoDTO pasoDTO);

        void eliminar(PasoDTO pasoDTO);

        List<PasoDTO> consultar(PasoDTO pasoDTO);

    }
}