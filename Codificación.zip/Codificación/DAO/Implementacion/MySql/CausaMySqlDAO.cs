﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using DAO.Interface;
using DTO;

namespace DAO.Implementacion.MySql
{
    public class CausaMySqlDAO : ICausaDAO
    {

        private MySqlTransaction transaccion;

        public CausaMySqlDAO(MySqlTransaction transaccion)
        {
            this.transaccion = transaccion;
        }

        public int crear(CausaDTO causaDTO)
        {
            int codigo = 0;
            try
            {
                String sentenciaSQL = "INSERT INTO bsb_causa(NV_NOMBRE, NM_TIPOLOGIA, NM_ESTADO) VALUES(@NV_NOMBRE, @NM_CODIGO_TIPOLOGIA, @NM_ESTADO); SELECT LAST_INSERT_ID();";
                using (MySqlCommand comandoSQL = new MySqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NV_NOMBRE", MySqlDbType.VarChar).Value = causaDTO.Nombre;
                    comandoSQL.Parameters.Add("@NM_CODIGO_TIPOLOGIA", MySqlDbType.Int32).Value = causaDTO.Tipologia.Codigo;
                    comandoSQL.Parameters.Add("@NM_ESTADO", MySqlDbType.Int24).Value = causaDTO.Estado;
                    codigo = int.Parse(comandoSQL.ExecuteScalar().ToString());
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return codigo;
        }

        public void actualizar(CausaDTO causaDTO)
        {
            try
            {
                String sentenciaSQL = "UPDATE bsb_causa SET NV_NOMBRE = @NV_NOMBRE, NM_TIPOLOGIA = @NM_CODIGO_TIPOLOGIA, NM_ESTADO = @NM_ESTADO WHERE NM_CODIGO = @NM_CODIGO";
                using (MySqlCommand comandoSQL = new MySqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NV_NOMBRE", MySqlDbType.VarChar).Value = causaDTO.Nombre;
                    comandoSQL.Parameters.Add("@NM_CODIGO_TIPOLOGIA", MySqlDbType.Int32).Value = causaDTO.Tipologia.Codigo;
                    comandoSQL.Parameters.Add("@NM_ESTADO", MySqlDbType.Int24).Value = causaDTO.Estado;
                    comandoSQL.Parameters.Add("@NM_CODIGO", MySqlDbType.Int32).Value = causaDTO.Codigo;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(CausaDTO causaDTO)
        {
            try
            {
                String sentenciaSQL = "DELETE FROM bsb_causa WHERE NM_CODIGO = @NM_CODIGO";
                using (MySqlCommand comandoSQL = new MySqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NM_CODIGO", MySqlDbType.Int32).Value = causaDTO.Codigo;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<CausaDTO> consultar(CausaDTO causaDTO)
        {
            List<CausaDTO> listaCausa = new List<CausaDTO>();
            try
            {
                String sentenciaSQL = "SELECT C.NM_CODIGO, C.NV_NOMBRE, C.NM_ESTADO, T.NM_CODIGO, T.NV_NOMBRE, P.NV_NOMBRE " + 
                                      "FROM bsb_causa C " + 
                                      "INNER JOIN bsb_tipologia T ON T.NM_CODIGO = C.NM_TIPOLOGIA " +
                                      "INNER JOIN bsb_producto P ON P.NM_CODIGO = T.NM_PRODUCTO WHERE 1";
                using (MySqlCommand comandoSQL = new MySqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Consultar por codigo
                    if (causaDTO.Codigo != 0)
                    {
                        sentenciaSQL += " AND C.NM_CODIGO = @NM_CODIGO";
                        comandoSQL.Parameters.Add("@NM_CODIGO", MySqlDbType.Int32).Value = causaDTO.Codigo;
                    }
                    // Consultar por nombre
                    if (causaDTO.Nombre != null && causaDTO.Nombre != "")
                    {
                        sentenciaSQL += " AND C.NV_NOMBRE LIKE @NV_NOMBRE";
                        comandoSQL.Parameters.Add("@NV_NOMBRE", MySqlDbType.VarChar).Value = "%" + causaDTO.Nombre + "%";
                    }
                    // Consultar por tipología
                    if (causaDTO.Tipologia != null && causaDTO.Tipologia.Codigo != 0)
                    {
                        sentenciaSQL += " AND T.NM_CODIGO = @NM_CODIGO_TIPOLOGIA";
                        comandoSQL.Parameters.Add("@NM_CODIGO_TIPOLOGIA", MySqlDbType.Int32).Value = causaDTO.Tipologia.Codigo;
                    }
                    // Consultar por producto
                    if (causaDTO.Tipologia != null && causaDTO.Tipologia.Producto != null && causaDTO.Tipologia.Producto.Codigo != 0)
                    {
                        sentenciaSQL += " AND P.NM_CODIGO = @NM_CODIGO_PRODUCTO";
                        comandoSQL.Parameters.Add("@NM_CODIGO_PRODUCTO", MySqlDbType.Int32).Value = causaDTO.Tipologia.Producto.Codigo;
                    }
                    sentenciaSQL += " ORDER BY C.NM_TIPOLOGIA, C.NV_NOMBRE";
                    comandoSQL.CommandText = sentenciaSQL;
                    using (MySqlDataReader cursorDatos = comandoSQL.ExecuteReader())
                    {
                        CausaDTO causaDTOTmp = null;
                        TipologiaDTO tipologiaDTOTmp = null;
                        ProductoDTO productoDTOTmp = null;
                        while (cursorDatos.Read())
                        {
                            causaDTOTmp = new CausaDTO();
                            causaDTOTmp.Codigo = cursorDatos.GetInt32(0);
                            causaDTOTmp.Nombre = cursorDatos.GetString(1);
                            causaDTOTmp.Estado = (int)cursorDatos.GetDecimal(2);
                            tipologiaDTOTmp = new TipologiaDTO();
                            tipologiaDTOTmp.Codigo = cursorDatos.GetInt32(3);
                            tipologiaDTOTmp.Nombre = cursorDatos.GetString(4);
                            productoDTOTmp = new ProductoDTO();
                            productoDTOTmp.Nombre = cursorDatos.GetString(5);
                            tipologiaDTOTmp.Producto = productoDTOTmp;
                            causaDTOTmp.Tipologia = tipologiaDTOTmp;
                            listaCausa.Add(causaDTOTmp);
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaCausa;
        }

    }
}