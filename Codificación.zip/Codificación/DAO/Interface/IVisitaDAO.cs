﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface IVisitaDAO
    {

        void crear(VisitaDTO visitaDTO);

        void actualizar(VisitaDTO visitaDTO);

        void eliminar(VisitaDTO visitaDTO);

        List<VisitaDTO> consultar(VisitaDTO visitaDTO);

    }
}