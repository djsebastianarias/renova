﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DTO;
using Modelo.Fachada;

namespace Modelo.Delegador
{
    public class ProductoDelegador
    {

        private ProductoFachada fachada = null;

        public ProductoDelegador()
        {
            try
            {
                fachada = new ProductoFachada();
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void crear(ProductoDTO productoDTO)
        {
            try
            {
                fachada.crear(productoDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(ProductoDTO productoDTO)
        {
            try
            {
                fachada.actualizar(productoDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(ProductoDTO productoDTO)
        {
            try
            {
                fachada.eliminar(productoDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<ProductoDTO> consultar(ProductoDTO productoDTO)
        {
            List<ProductoDTO> listaProductos = null;
            try
            {
                listaProductos = fachada.consultar(productoDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaProductos;
        }

    }
}