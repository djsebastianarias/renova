﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DTO;
using Modelo.Delegador;
using Transversal;

namespace Vista.Paginas
{
    public partial class Causas : System.Web.UI.Page
    {

        // Definir clases que se requieren para ejecución de la página
        TipologiaDelegador tipologiaDelegador = new TipologiaDelegador();
        CausaDelegador causaDelegador = new CausaDelegador();
        PasoDelegador pasoDelegador = new PasoDelegador();

        protected void Page_Load(object sender, EventArgs e)
        {
            // Ejecutar al cargar la página por primera vez
            if (!IsPostBack)
            {
                // Mostrar Tipologias
                mostrarTipologias();
            }
        }

        // Mostrar Tipologias
        private void mostrarTipologias()
        {
            List<TipologiaDTO> listaTipologias = tipologiaDelegador.consultar(new TipologiaDTO());
            var tipologias = from t in listaTipologias
                            select new
                            {
                                codigo = t.Codigo,
                                nombre = t.Nombre
                            };
            ddlTipologia.DataSource = tipologias.ToList();
            ddlTipologia.DataBind();
            ListItem item = new ListItem("Seleccione", "");
            ddlTipologia.Items.Insert(0, item);
        }

        // Evento Click del botón Consultar
        protected void btConsultar_Click(object sender, EventArgs e)
        {
            mostrarCausas();
        }

        // Mostrar Causas
        private void mostrarCausas()
        {
            CausaDTO causaDTO = new CausaDTO();
            causaDTO.Nombre = tbNombre.Text;
            if (ddlTipologia.SelectedValue != "")
            {
                TipologiaDTO tipologiaDTO = new TipologiaDTO();
                tipologiaDTO.Codigo = int.Parse(ddlTipologia.SelectedValue);
                causaDTO.Tipologia = tipologiaDTO;
            }
            List<CausaDTO> listaCausas = causaDelegador.consultar(causaDTO);
            var causas = from c in listaCausas
                             select new
                             {
                                 codigo = c.Codigo,
                                 tipologia = c.Tipologia.Nombre,
                                 nombre = c.Nombre,
                                 estado = Constantes.Estado[c.Estado]
                             };
            gvCausas.DataSource = causas.ToList();
            gvCausas.DataBind();
            gvCausas.Visible = true;
        }

        // Evento Click del botón Guardar
        protected void btGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                guardarCausa();
                limpiarCampos();
                gvCausas.Visible = false;
                ClientScript.RegisterStartupScript(this.GetType(), "mensaje", "mensaje('Casuística guardada correctamente');", true);
            }
            catch (Exception exc)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('Error al guardar');", true);
            }
        }

        // Guardar Causa
        private void guardarCausa()
        {
            CausaDTO causaDTO = new CausaDTO();
            causaDTO.Nombre = tbNombre.Text;
            TipologiaDTO tipologiaDTO = new TipologiaDTO();
            tipologiaDTO.Codigo = int.Parse(ddlTipologia.SelectedValue);
            causaDTO.Tipologia = tipologiaDTO;
            causaDTO.Estado = int.Parse(ddlEstado.SelectedValue);
            // Actualizar
            if (hfCausa.Value != "")
            {
                causaDTO.Codigo = int.Parse(hfCausa.Value);
                causaDelegador.actualizar(causaDTO);
            }
            // Guardar
            else
            {
                int codigo = causaDelegador.crear(causaDTO);
                hfCausa.Value = codigo.ToString();
            }
        }

        // Paginación
        protected void gvCausas_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvCausas.PageIndex = e.NewPageIndex;
            mostrarCausas();
        }

        // Opciones Causa
        protected void gvCausas_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int index = Convert.ToInt32(e.CommandArgument);
            // Editar 
            if (e.CommandName.Equals("editar"))
            {
                hfCausa.Value = gvCausas.DataKeys[index].Value.ToString();
                CausaDTO causaDTO = new CausaDTO();
                causaDTO.Codigo = int.Parse(hfCausa.Value);
                causaDTO = causaDelegador.consultar(causaDTO)[0];
                tbNombre.Text = causaDTO.Nombre;
                ddlTipologia.SelectedValue = causaDTO.Tipologia.Codigo.ToString();
                ddlEstado.SelectedValue = causaDTO.Estado.ToString();
                mostrarPasos();
            }
            // Eliminar Causa
            else if (e.CommandName.Equals("eliminar"))
            {
                hfCausa.Value = gvCausas.DataKeys[index].Value.ToString();
                mpeEliminarCausa.Enabled = true;
                mpeEliminarCausa.Show();
            }
        }

        // Evento Click del botón Confirmar eliminar causa
        protected void btDeleteCausa_Click(object sender, EventArgs e)
        {
            try
            {
                CausaDTO causaDTO = new CausaDTO();
                causaDTO.Codigo = int.Parse(hfCausa.Value);
                causaDelegador.eliminar(causaDTO);
                gvCausas.Visible = false;
                ClientScript.RegisterStartupScript(this.GetType(), "mensaje", "mensaje('Casuística eliminada correctamente');", true);
            }
            catch (Exception exc)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('Error al eliminar');", true);
            }
            finally
            {
                limpiarCampos();
            }
        }

        // Evento Click del botón Cancelar eliminar causa
        protected void btCancelarEliminarCausa_Click(object sender, EventArgs e)
        {
            limpiarCampos();
        }

        // Limpiar Campos
        private void limpiarCampos()
        {
            tbNombre.Text = tbRecomendaciones.Text = ddlTipologia.SelectedValue = ddlEstado.SelectedValue = hfCausa.Value = "";
            mpeEliminarCausa.Enabled = gvCausas.Visible = gvPasos.Visible = false;
            mpeEliminarCausa.Hide();
        }

        // Evento Click botón Cancelar
        protected void btCancelar_Click(object sender, EventArgs e)
        {
            limpiarCampos();
        }

        // Agregar paso
        protected void btAgregarPaso_Click(object sender, EventArgs e)
        {
            if (hfCausa.Value.Equals(""))
            {
                guardarCausa();
            }
            mpePaso.Enabled = true;
            mpePaso.Show();
        }

        // Opciones Pasos
        protected void gvPasos_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int index = Convert.ToInt32(e.CommandArgument);
            // Editar 
            if (e.CommandName.Equals("editar"))
            {
                hfPaso.Value = gvPasos.DataKeys[index].Value.ToString();
                PasoDTO pasoDTO = new PasoDTO();
                pasoDTO.Codigo = int.Parse(hfPaso.Value);
                pasoDTO = pasoDelegador.consultar(pasoDTO)[0];
                tbDescripcion.Text = pasoDTO.Descripcion;
                // Escalar
                if (pasoDTO.Escala != "" && pasoDTO.Escala != "No")
                {
                    ddlEscalar.SelectedValue = "Si";
                    tbEscala.Text = pasoDTO.Escala;
                    tbNivel2.Text = pasoDTO.SegundoNivel;
                    divEscalar.Attributes.Add("style", "display:block");
                }
                else
                {
                    ddlEscalar.SelectedValue = "No";
                    tbEscala.Text = tbNivel2.Text = "";
                    divEscalar.Attributes.Add("style", "display:none");
                }
                tbRecomendaciones.Text = pasoDTO.Recomendaciones;
                mpePaso.Enabled = true;
                mpePaso.Show();
            }
            // Eliminar Causa
            else if (e.CommandName.Equals("eliminar"))
            {
                hfPaso.Value = gvPasos.DataKeys[index].Value.ToString();
                mpeEliminarPaso.Enabled = true;
                mpeEliminarPaso.Show();
            }
        }

        // Guardar Paso
        protected void btGuardarPaso_Click(object sender, EventArgs e)
        {
            try
            {
                PasoDTO pasoDTO = new PasoDTO();
                CausaDTO causaDTO = new CausaDTO();
                causaDTO.Codigo = int.Parse(hfCausa.Value);
                pasoDTO.Causa = causaDTO;
                pasoDTO.Descripcion = tbDescripcion.Text;
                pasoDTO.Escala = ddlEscalar.SelectedValue;
                pasoDTO.SegundoNivel = "";
                pasoDTO.Recomendaciones = tbRecomendaciones.Text;
                // Escalar
                if (ddlEscalar.SelectedValue.Equals("Si"))
                {
                    pasoDTO.Escala = tbEscala.Text;
                    pasoDTO.SegundoNivel = tbNivel2.Text;
                }
                // Actualizar
                if (hfPaso.Value != null && hfPaso.Value != "")
                {
                    pasoDTO.Codigo = int.Parse(hfPaso.Value);
                    pasoDelegador.actualizar(pasoDTO);
                }
                // Guardar
                else
                {
                    pasoDelegador.crear(pasoDTO);
                }
                mostrarPasos();
                limpiarPaso();
                ClientScript.RegisterStartupScript(this.GetType(), "mensaje", "mensaje('Paso guardado correctamente');", true);
            }
            catch (Exception exc)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('Error al guardar');", true);
            }
        }

        // Cerrar paso
        protected void btCerrarPaso_Click(object sender, EventArgs e)
        {
            limpiarPaso();
        }

        // Limpiar Paso
        private void limpiarPaso()
        {
            tbDescripcion.Text = ddlEscalar.SelectedValue = tbEscala.Text = tbNivel2.Text = hfPaso.Value = "";
            divEscalar.Attributes.Add("style", "display:none");
            mpePaso.Enabled = false;
            mpePaso.Hide();
        }

        // Evento Click del botón Confirmar eliminar paso
        protected void btDeletePaso_Click(object sender, EventArgs e)
        {
            try
            {
                PasoDTO pasoDTO = new PasoDTO();
                pasoDTO.Codigo = int.Parse(hfPaso.Value);
                pasoDelegador.eliminar(pasoDTO);
                mostrarPasos();
                mpeEliminarPaso.Enabled = false;
                mpeEliminarPaso.Hide();
                ClientScript.RegisterStartupScript(this.GetType(), "mensaje", "mensaje('Paso eliminado correctamente');", true);
            }
            catch (Exception exc)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('Error al eliminar');", true);
            }
            finally
            {
                limpiarPaso();
            }
        }

        // Mostrar Pasos
        private void mostrarPasos()
        {
            CausaDTO causaDTO = new CausaDTO();
            causaDTO.Codigo = int.Parse(hfCausa.Value);
            PasoDTO pasoDTO = new PasoDTO();
            pasoDTO.Causa = causaDTO;
            List<PasoDTO> listaPaso = pasoDelegador.consultar(pasoDTO);
            var pasos = from p in listaPaso
                        select new
                        {
                            codigo = p.Codigo,
                            descripcion = p.Descripcion,
                            escala = p.Escala,
                            nivel2 = p.SegundoNivel,
                            recomendaciones = p.Recomendaciones
                        };
            gvPasos.DataSource = pasos.ToList();
            gvPasos.DataBind();
            gvPasos.Visible = true;
        }

        // Evento Click del botón Cancelar eliminar paso
        protected void btCancelarEliminarPaso_Click(object sender, EventArgs e)
        {
            limpiarPaso();
        }

    }
}