﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface ICurvaDAO
    {

        void crear(CurvaDTO curvaDTO);

        void actualizar(CurvaDTO curvaDTO);

        void eliminar(CurvaDTO curvaDTO);

        List<CurvaDTO> consultar(CurvaDTO curvaDTO);

    }
}