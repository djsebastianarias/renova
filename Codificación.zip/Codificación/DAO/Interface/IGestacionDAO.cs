﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface IGestacionDAO
    {

        void crear(GestacionDTO gestacionDTO);

        void actualizar(GestacionDTO gestacionDTO);

        void reiniciar(GestacionDTO gestacionDTO);
        void eliminar(GestacionDTO gestacionDTO);

        List<GestacionDTO> consultar(GestacionDTO gestacionDTO);
        List<GestacionDTO> notificacion(GestacionDTO gestacionDTO);

    }
}