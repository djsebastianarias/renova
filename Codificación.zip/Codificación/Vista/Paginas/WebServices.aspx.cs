﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using DTO;
using Modelo.Delegador;

namespace VISTA.Paginas
{
    public partial class WebServices : System.Web.UI.Page
    {
        
        // WebMethod Consultar Tipologías
        [WebMethod]
        public static List<TipologiaDTO> GetTipologias(int codigoProducto)
        {
            TipologiaDelegador tipologiaDelegador = new TipologiaDelegador();
            ProductoDTO productoDTO = new ProductoDTO();
            productoDTO.Codigo = codigoProducto;
            TipologiaDTO tipologiaDTO = new TipologiaDTO();
            tipologiaDTO.Producto = productoDTO;
            return tipologiaDelegador.consultar(tipologiaDTO);
        }

        // WebMethod Consultar Causas
        [WebMethod]
        public static List<CausaDTO> GetCausas(int codigoTipologia)
        {
            CausaDelegador causaDelegador = new CausaDelegador();
            TipologiaDTO tipologiaDTO = new TipologiaDTO();
            tipologiaDTO.Codigo = codigoTipologia;
            CausaDTO causaDTO = new CausaDTO();
            causaDTO.Tipologia = tipologiaDTO;
            return causaDelegador.consultar(causaDTO);
        }

    }
}