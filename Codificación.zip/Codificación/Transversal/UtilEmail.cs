﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;
using System.Net;
using DTO;

namespace Transversal
{
    public class UtilEmail
    {

        // Recuperar password
        public static void recuperarPassword(UsuarioDTO usuarioDTO)
        {
            try
            {
                MailMessage mail = new MailMessage();
                mail.Subject = "Olvidé mis datos - BITASOL WEB";
                // Cuerpo del mensaje 
                mail.Body = "<h2>Estimado Usuario,</h2></br>" +
                            "<p>Su contraseña es: " + usuarioDTO.Password + "</p></br></br></br>" +
                            "<p>Por motivos de seguridad le recomendamos cambiar la contraseña y eliminar este correo electrónico. Agradecemos su colaboración.</p></br></br>" +
                            "<p>Correo enviado desde el aplicativo BITASOL WEB Bancolombia</p>";
                mail.IsBodyHtml = true;
                // Destinatario
                mail.To.Add(usuarioDTO.Email);
                enviarEmail(mail);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // Enviar email
        private static void enviarEmail(MailMessage mail)
        {
            try
            {
                // Configuracion del SMTP
                string email = "info@info.com";
                mail.From = new MailAddress(email, "BITASOL WEB Bancolombia", Encoding.UTF8);
                SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
                SmtpServer.Port = 587;

                // Credenciales
                SmtpServer.Credentials = new System.Net.NetworkCredential(email, "password_email");
                SmtpServer.EnableSsl = true;
                SmtpServer.Send(mail);
            }
            catch (SmtpException ex)
            {
                throw ex;
            }
        }

    }
}
