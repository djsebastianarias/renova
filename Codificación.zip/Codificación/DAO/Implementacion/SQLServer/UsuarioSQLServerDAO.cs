﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Security.Cryptography;
using System.Data.SqlClient;
using System.Data;
using DAO.Interface;
using DTO;

namespace DAO.Implementacion.SQLServer
{
    public class UsuarioSQLServerDAO : IUsuarioDAO
    {

        private SqlTransaction transaccion;

        public UsuarioSQLServerDAO(SqlTransaction transaccion)
        {
            this.transaccion = transaccion;
        }

        public void crear(UsuarioDTO usuarioDTO)
        {
            try
            {
                String sentenciaSQL = "INSERT INTO bsb_usuario(NM_ROL, NV_ID, NV_NOMBRE, NV_EMAIL, NM_ESTADO, NV_PASS) VALUES(@NM_CODIGO_ROL, @NV_ID, @NV_NOMBRE, @NV_EMAIL, 1, '')";
                using (SqlCommand comandoSQL = new SqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NM_CODIGO_ROL", SqlDbType.Int).Value = usuarioDTO.Rol.Codigo;
                    comandoSQL.Parameters.Add("@NV_ID", SqlDbType.VarChar).Value = usuarioDTO.Id;
                    comandoSQL.Parameters.Add("@NV_NOMBRE", SqlDbType.VarChar).Value = usuarioDTO.Nombre;
                    comandoSQL.Parameters.Add("@NV_EMAIL", SqlDbType.VarChar).Value = usuarioDTO.Email;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(UsuarioDTO usuarioDTO)
        {
            try
            {
                String sentenciaSQL = "UPDATE bsb_usuario SET NV_NOMBRE = @NV_NOMBRE, NV_EMAIL = @NV_EMAIL, NV_PASS = @NV_PASS WHERE NM_CODIGO = @NM_CODIGO";
                using (SqlCommand comandoSQL = new SqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NV_NOMBRE", SqlDbType.VarChar).Value = usuarioDTO.Nombre;
                    comandoSQL.Parameters.Add("@NV_EMAIL", SqlDbType.VarChar).Value = usuarioDTO.Email;
                    comandoSQL.Parameters.Add("@NV_PASS", SqlDbType.VarChar).Value = usuarioDTO.Password;
                    comandoSQL.Parameters.Add("@NM_CODIGO", SqlDbType.Int).Value = usuarioDTO.Codigo;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(UsuarioDTO usuarioDTO)
        {
            try
            {
                String sentenciaSQL = "UPDATE bsb_usuario SET NM_ESTADO = 0 WHERE NM_CODIGO = @NM_CODIGO";
                using (SqlCommand comandoSQL = new SqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NM_CODIGO", SqlDbType.Int).Value = usuarioDTO.Codigo;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<UsuarioDTO> consultar(UsuarioDTO usuarioDTO)
        {
            List<UsuarioDTO> listaUsuario = new List<UsuarioDTO>();
            try
            {
                String sentenciaSQL = "SELECT NM_CODIGO, NV_ID, NV_NOMBRE, NV_EMAIL, NM_ESTADO, NV_PASS FROM bsb_usuario WHERE NM_CODIGO > 0";
                using (SqlCommand comandoSQL = new SqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Consultar por Id
                    if (usuarioDTO.Id != null && usuarioDTO.Id != "")
                    {
                        sentenciaSQL += " AND NV_ID = @NV_ID";
                        comandoSQL.Parameters.Add("@NV_ID", SqlDbType.VarChar).Value = usuarioDTO.Id;
                    }
                    // Consultar por Email
                    if (usuarioDTO.Email != null && usuarioDTO.Email != "")
                    {
                        sentenciaSQL += " AND NV_EMAIL = @NV_EMAIL";
                        comandoSQL.Parameters.Add("@NV_EMAIL", SqlDbType.VarChar).Value = usuarioDTO.Email;
                    }
                    // Consultar por Nombre
                    if (usuarioDTO.Nombre != null && usuarioDTO.Nombre != "")
                    {
                        sentenciaSQL += " AND NV_NOMBRE LIKE @NV_NOMBRE";
                        comandoSQL.Parameters.Add("@NV_NOMBRE", SqlDbType.VarChar).Value = "%" + usuarioDTO.Nombre + "%";
                    }
                    sentenciaSQL += " ORDER BY NV_NOMBRE";
                    comandoSQL.CommandText = sentenciaSQL;
                    using (SqlDataReader cursorDatos = comandoSQL.ExecuteReader())
                    {
                        UsuarioDTO usuarioDTOTmp = null;
                        while (cursorDatos.Read())
                        {
                            usuarioDTOTmp = new UsuarioDTO();
                            usuarioDTOTmp.Codigo = cursorDatos.GetInt32(0);
                            usuarioDTOTmp.Id = cursorDatos.GetString(1);
                            usuarioDTOTmp.Nombre = cursorDatos.GetString(2);
                            usuarioDTOTmp.Email = cursorDatos.GetString(3);
                            usuarioDTOTmp.Estado = (int)cursorDatos.GetDecimal(4);
                            usuarioDTOTmp.Password = descifrar(usuarioDTOTmp.Id, cursorDatos.GetString(5));
                            listaUsuario.Add(usuarioDTOTmp);
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaUsuario;
        }

        // Descifrar password
        private string descifrar(string id, string password)
        {
            string res = "";
            try
            {
                if (password != "")
                {
                    byte[] keyArray;
                    byte[] Array_a_Descifrar = Convert.FromBase64String(password);
                    MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                    keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(id));
                    hashmd5.Clear();
                    TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
                    tdes.Key = keyArray;
                    tdes.Mode = CipherMode.ECB;
                    tdes.Padding = PaddingMode.PKCS7;
                    ICryptoTransform cTransform = tdes.CreateDecryptor();
                    byte[] resultArray = cTransform.TransformFinalBlock(Array_a_Descifrar, 0, Array_a_Descifrar.Length);
                    tdes.Clear();
                    res = UTF8Encoding.UTF8.GetString(resultArray);
                }
            }
            catch (Exception exc)
            {
                res = "";
            }
            return res;
        }

    }
}