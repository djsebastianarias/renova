﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface IEstacionDAO
    {

        void crear(EstacionDTO estacionDTO);

        void actualizar(EstacionDTO estacionDTO);

        void eliminar(EstacionDTO estacionDTO);

        List<EstacionDTO> consultar(EstacionDTO estacionDTO);

    }
}
