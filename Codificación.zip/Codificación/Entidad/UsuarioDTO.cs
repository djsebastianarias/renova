﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DTO
{
    public class UsuarioDTO
    {

        private int codigo;

        public int Codigo
        {
            get { return codigo; }
            set { codigo = value; }
        }

        private RolDTO rol;

        public RolDTO Rol
        {
            get { return rol; }
            set { rol = value; }
        }

        private string id;

        public string Id
        {
            get { return id; }
            set { id = value; }
        }

        private string nombre;

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        private string email;

        public string Email
        {
            get { return email; }
            set { email = value; }
        }        

        private int estado;

        public int Estado
        {
            get { return estado; }
            set { estado = value; }
        }

        private string password;

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

    }
}