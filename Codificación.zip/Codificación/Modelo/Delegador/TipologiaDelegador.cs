﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DTO;
using Modelo.Fachada;

namespace Modelo.Delegador
{
    public class TipologiaDelegador
    {

        private TipologiaFachada fachada = null;

        public TipologiaDelegador()
        {
            try
            {
                fachada = new TipologiaFachada();
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void crear(TipologiaDTO tipologiaDTO)
        {
            try
            {
                fachada.crear(tipologiaDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(TipologiaDTO tipologiaDTO)
        {
            try
            {
                fachada.actualizar(tipologiaDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(TipologiaDTO tipologiaDTO)
        {
            try
            {
                fachada.eliminar(tipologiaDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<TipologiaDTO> consultar(TipologiaDTO tipologiaDTO)
        {
            List<TipologiaDTO> listaTipologias = null;
            try
            {
                listaTipologias = fachada.consultar(tipologiaDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaTipologias;
        }

    }
}