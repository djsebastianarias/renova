﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DTO;

namespace DAO.Interface
{
    public interface ICausaDAO
    {

        int crear(CausaDTO causaDTO);

        void actualizar(CausaDTO causaDTO);

        void eliminar(CausaDTO causaDTO);

        List<CausaDTO> consultar(CausaDTO causaDTO);

    }
}