﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DTO;
using Modelo.Fachada;

namespace Modelo.Delegador
{
    public class PasoDelegador
    {

        private PasoFachada fachada = null;

        public PasoDelegador()
        {
            try
            {
                fachada = new PasoFachada();
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void crear(PasoDTO pasoDTO)
        {
            try
            {
                fachada.crear(pasoDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(PasoDTO pasoDTO)
        {
            try
            {
                fachada.actualizar(pasoDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(PasoDTO pasoDTO)
        {
            try
            {
                fachada.eliminar(pasoDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<PasoDTO> consultar(PasoDTO pasoDTO)
        {
            List<PasoDTO> listaPasos = null;
            try
            {
                listaPasos = fachada.consultar(pasoDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaPasos;
        }

    }
}