﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Transversal
{
    public class Constantes
    {

        // Meses
        public static String[] Meses = new String[] { "", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre" }; 
        
        // Boolean
        public static String[] Boolean = new String[] { "No", "Si" };

        // Estado
        public static String[] Estado = new String[] { "Inactivo", "Activo" };

    }
}
