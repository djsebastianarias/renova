﻿using System;
using DAO.Implementacion.MySql;
using DAO.Interface;
using MySql.Data.MySqlClient;
using System.Data;
using System.Configuration;

namespace DAO.DAOFactory
{
    public class MySqlDAOFactory : DAOFactory
    {

        private MySqlConnection conexion = null;

        private MySqlTransaction transaccion = null;

        // Constructor de la clase, encargado de abrir la conexión a la base de datos
        public MySqlDAOFactory()
        {
            try
            {
                string conString = ConfigurationManager.ConnectionStrings["conexionMySQL"].ConnectionString;
                conexion = new MySqlConnection(conString);
                conexion.Open();
                iniciarTransaccion();
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        // Método para iniciar una transacción de base de datos
        public override void iniciarTransaccion()
        {
            if (conexion != null)
            {
                transaccion = conexion.BeginTransaction(IsolationLevel.ReadUncommitted);
            }
        }

        // Método para confirmar una transacción de base de datos
        public override void confirmarTransaccion()
        {
            if (transaccion != null)
            {
                transaccion.Commit();
            }
        }

        // Método para cancelar una transacción de base de datos
        public override void cancelarTransaccion()
        {
            if (transaccion != null)
            {
                transaccion.Rollback();
            }
        }

        // Método cerrar la conexión a la base de datos
        public override void cerrarConexion()
        {
            if (transaccion != null)
            {
                transaccion.Dispose();
            }
            if (conexion != null)
            {
                conexion.Close();
                conexion.Dispose();
            }
        }

        public override ICausaDAO getCausaDAO()
        {
            return new CausaMySqlDAO(transaccion);
        }

        public override IEntidadDAO getEntidadDAO()
        {
            return new EntidadMySqlDAO(transaccion);
        }

        public override IPasoDAO getPasoDAO()
        {
            return new PasoMySqlDAO(transaccion);
        }

        public override IProductoDAO getProductoDAO()
        {
            return new ProductoMySqlDAO(transaccion);
        }

        public override ITipologiaDAO getTipologiaDAO()
        {
            return new TipologiaMySqlDAO(transaccion);
        }

        public override IUsuarioDAO getUsuarioDAO()
        {
            return new UsuarioMySqlDAO(transaccion);
        }

    }
}