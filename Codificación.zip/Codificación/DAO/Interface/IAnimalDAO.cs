﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface IAnimalDAO
    {

        int crear(AnimalDTO animalDTO);

        void actualizar(AnimalDTO animalDTO);
        void actualizarImc(AnimalDTO animalDTO);
        void actualizarEstado(AnimalDTO animalDTO);

        void eliminar(AnimalDTO animalDTO);

        List<AnimalDTO> consultar(AnimalDTO animalDTO);

    }
}