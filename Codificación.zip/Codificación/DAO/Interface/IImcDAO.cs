﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface IImcDAO
    {

        void crear(ImcDTO imcDTO);

        void actualizar(ImcDTO imcDTO);

        void eliminar(ImcDTO imcDTO);

        List<ImcDTO> consultar(ImcDTO imcDTO);
        List<ImcDTO> reporteMensual(ImcDTO imcDTO);
        List<ImcDTO> curvaGestacion(ImcDTO imcDTO);

    }
}