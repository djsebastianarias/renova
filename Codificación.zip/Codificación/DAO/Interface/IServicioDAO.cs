﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface IServicioDAO
    {

        void crear(ServicioDTO servicioDTO);

        void actualizar(ServicioDTO servicioDTO);

        void eliminar(ServicioDTO servicioDTO);

        List<ServicioDTO> consultar(ServicioDTO servicioDTO);

    }
}
