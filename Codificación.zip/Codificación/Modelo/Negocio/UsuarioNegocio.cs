﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using DAO.Interface;
using DTO;
using DAO.DAOFactory;

namespace Modelo.Negocio
{
    public class UsuarioNegocio
    {

        public void crear(UsuarioDTO usuarioDTO, DAOFactory dao)
        {
            try
            {
                IUsuarioDAO usuarioDAO = dao.getUsuarioDAO();
                usuarioDTO.Password = cifrar(usuarioDTO);
                usuarioDAO.crear(usuarioDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(UsuarioDTO usuarioDTO, DAOFactory dao)
        {
            try
            {
                IUsuarioDAO usuarioDAO = dao.getUsuarioDAO();
                usuarioDTO.Password = cifrar(usuarioDTO);
                usuarioDAO.actualizar(usuarioDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(UsuarioDTO usuarioDTO, DAOFactory dao)
        {
            try
            {
                IUsuarioDAO usuarioDAO = dao.getUsuarioDAO();
                usuarioDAO.eliminar(usuarioDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<UsuarioDTO> consultar(UsuarioDTO usuarioDTO, DAOFactory dao)
        {
            List<UsuarioDTO> listaRetorno = null;
            try
            {                
                IUsuarioDAO usuarioDAO = dao.getUsuarioDAO();
                listaRetorno = usuarioDAO.consultar(usuarioDTO);
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaRetorno;
        }

        // Cifrar password
        private string cifrar(UsuarioDTO usuarioDTO)
        {
            string res = "";
            try
            {
                if (usuarioDTO.Password != "")
                {
                    byte[] keyArray;
                    byte[] Arreglo_a_Cifrar = UTF8Encoding.UTF8.GetBytes(usuarioDTO.Password);
                    MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                    keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(usuarioDTO.Id));
                    hashmd5.Clear();
                    TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
                    tdes.Key = keyArray;
                    tdes.Mode = CipherMode.ECB;
                    tdes.Padding = PaddingMode.PKCS7;
                    ICryptoTransform cTransform = tdes.CreateEncryptor();
                    byte[] ArrayResultado = cTransform.TransformFinalBlock(Arreglo_a_Cifrar, 0, Arreglo_a_Cifrar.Length);
                    tdes.Clear();
                    res = Convert.ToBase64String(ArrayResultado, 0, ArrayResultado.Length);
                }
            }
            catch (Exception exc)
            {
                res = "";
            }
            return res;
        }

    }
}
