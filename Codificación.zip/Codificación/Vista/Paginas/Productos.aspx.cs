﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DTO;
using Modelo.Delegador;
using Transversal;

namespace Vista.Paginas
{
    public partial class Productos : System.Web.UI.Page
    {

        // Definir clases que se requieren para ejecución de la página
        EntidadDelegador entidadDelegador = new EntidadDelegador();
        ProductoDelegador productoDelegador = new ProductoDelegador();

        protected void Page_Load(object sender, EventArgs e)
        {
            // Ejecutar al cargar la página por primera vez
            if (!IsPostBack)
            {
                // Mostrar Entidades
                mostrarEntidades();
            }
        }

        // Mostrar Entidades
        private void mostrarEntidades()
        {
            List<EntidadDTO> listaEntidades = entidadDelegador.consultar(new EntidadDTO());
            var entidades = from e in listaEntidades
                            select new
                            {
                                codigo = e.Codigo,
                                nombre = e.Nombre
                            };
            ddlEntidad.DataSource = entidades.ToList();
            ddlEntidad.DataBind();
            ListItem item = new ListItem("Seleccione", "");
            ddlEntidad.Items.Insert(0, item);
        }

        // Evento Click del botón Consultar
        protected void btConsultar_Click(object sender, EventArgs e)
        {
            mostrarProductos();
        }

        // Mostrar Productos
        private void mostrarProductos()
        {
            ProductoDTO productoDTO = new ProductoDTO();
            productoDTO.Nombre = tbNombre.Text;
            if (ddlEntidad.SelectedValue != "")
            {
                EntidadDTO entidadDTO = new EntidadDTO();
                entidadDTO.Codigo = int.Parse(ddlEntidad.SelectedValue);
                productoDTO.Entidad = entidadDTO;
            }
            List<ProductoDTO> listaProductos = productoDelegador.consultar(productoDTO);
            var productos = from p in listaProductos
                            select new
                            {
                                codigo = p.Codigo,
                                entidad = p.Entidad.Nombre,
                                nombre = p.Nombre,
                                estado = Constantes.Estado[p.Estado]
                            };
            gvProductos.DataSource = productos.ToList();
            gvProductos.DataBind();
            gvProductos.Visible = true;
        }

        // Evento Click del botón Guardar
        protected void btGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                ProductoDTO productoDTO = new ProductoDTO();
                productoDTO.Nombre = tbNombre.Text;
                EntidadDTO entidadDTO = new EntidadDTO();
                entidadDTO.Codigo = int.Parse(ddlEntidad.SelectedValue);
                productoDTO.Entidad = entidadDTO;
                productoDTO.Estado = int.Parse(ddlEstado.SelectedValue);
                // Actualizar 
                if (hfCodigo.Value != "")
                {
                    productoDTO.Codigo = int.Parse(hfCodigo.Value);
                    productoDelegador.actualizar(productoDTO);
                }
                // Guardar
                else
                {
                    productoDelegador.crear(productoDTO);
                }
                limpiarCampos();
                gvProductos.Visible = false;
                ClientScript.RegisterStartupScript(this.GetType(), "mensaje", "mensaje('Producto guardado correctamente');", true);
            }
            catch (Exception exc)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('Error al guardar');", true);
            }
        }

        // Paginación
        protected void gvProductos_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvProductos.PageIndex = e.NewPageIndex;
            mostrarProductos();
        }

        // Opciones
        protected void gvProductos_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int index = Convert.ToInt32(e.CommandArgument);
            // Editar 
            if (e.CommandName.Equals("editar"))
            {
                hfCodigo.Value = gvProductos.DataKeys[index].Value.ToString();
                ProductoDTO productoDTO = new ProductoDTO();
                productoDTO.Codigo = int.Parse(hfCodigo.Value);
                productoDTO = productoDelegador.consultar(productoDTO)[0];
                tbNombre.Text = productoDTO.Nombre;
                ddlEntidad.SelectedValue = productoDTO.Entidad.Codigo.ToString();
                ddlEstado.SelectedValue = productoDTO.Estado.ToString();
            }
            // Eliminar
            else if (e.CommandName.Equals("eliminar"))
            {
                hfCodigo.Value = gvProductos.DataKeys[index].Value.ToString();
                mpeEliminar.Enabled = true;
                mpeEliminar.Show();
            }
        }

        // Evento Click del botón Delete
        protected void btDelete_Click(object sender, EventArgs e)
        {
            try
            {
                ProductoDTO productoDTO = new ProductoDTO();
                productoDTO.Codigo = int.Parse(hfCodigo.Value);
                productoDelegador.eliminar(productoDTO);
                gvProductos.Visible = false;
                ClientScript.RegisterStartupScript(this.GetType(), "mensaje", "mensaje('Producto eliminado correctamente');", true);
            }
            catch (Exception exc)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('No se puede eliminar este Producto porque tiene tipologías asociadas');", true);
            }
            finally
            {
                limpiarCampos();
            }
        }

        // Evento Click del botón Cancelar eliminar
        protected void btCancelarEliminar_Click(object sender, EventArgs e)
        {
            limpiarCampos();
        }

        // Limpiar Campos
        private void limpiarCampos()
        {
            tbNombre.Text = ddlEntidad.SelectedValue = ddlEstado.SelectedValue = hfCodigo.Value = "";
            mpeEliminar.Enabled = gvProductos.Visible = false;
            mpeEliminar.Hide();
        }

        // Evento Click botón Cancelar
        protected void btCancelar_Click(object sender, EventArgs e)
        {
            limpiarCampos();
        }

    }
}