﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using DAO.Interface;
using DTO;

namespace DAO.Implementacion.MySql
{
    public class PasoMySqlDAO : IPasoDAO
    {

        private MySqlTransaction transaccion;

        public PasoMySqlDAO(MySqlTransaction transaccion)
        {
            this.transaccion = transaccion;
        }

        public void crear(PasoDTO pasoDTO)
        {
            try
            {
                String sentenciaSQL = "INSERT INTO bsb_paso(NM_CAUSA, NV_DESCRIPCION, NV_ESCALA, NV_NIVEL2, NV_RECOMENDACIONES) VALUES(@NM_CODIGO_CAUSA, @NV_DESCRIPCION, @NV_ESCALA, @NV_NIVEL2, @NV_RECOMENDACIONES)";
                using (MySqlCommand comandoSQL = new MySqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NM_CODIGO_CAUSA", MySqlDbType.Int32).Value = pasoDTO.Causa.Codigo;
                    comandoSQL.Parameters.Add("@NV_DESCRIPCION", MySqlDbType.VarChar).Value = pasoDTO.Descripcion;
                    comandoSQL.Parameters.Add("@NV_ESCALA", MySqlDbType.VarChar).Value = pasoDTO.Escala;
                    comandoSQL.Parameters.Add("@NV_NIVEL2", MySqlDbType.VarChar).Value = pasoDTO.SegundoNivel;
                    comandoSQL.Parameters.Add("@NV_RECOMENDACIONES", MySqlDbType.VarChar).Value = pasoDTO.Recomendaciones;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void actualizar(PasoDTO pasoDTO)
        {
            try
            {
                String sentenciaSQL = "UPDATE bsb_paso SET NM_CAUSA = @NM_CODIGO_CAUSA, NV_DESCRIPCION = @NV_DESCRIPCION, NV_ESCALA = @NV_ESCALA, NV_NIVEL2 = @NV_NIVEL2, NV_RECOMENDACIONES = @NV_RECOMENDACIONES WHERE NM_CODIGO = @NM_CODIGO";
                using (MySqlCommand comandoSQL = new MySqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NM_CODIGO_CAUSA", MySqlDbType.Int32).Value = pasoDTO.Causa.Codigo;
                    comandoSQL.Parameters.Add("@NV_DESCRIPCION", MySqlDbType.VarChar).Value = pasoDTO.Descripcion;
                    comandoSQL.Parameters.Add("@NV_ESCALA", MySqlDbType.VarChar).Value = pasoDTO.Escala;
                    comandoSQL.Parameters.Add("@NV_NIVEL2", MySqlDbType.VarChar).Value = pasoDTO.SegundoNivel;
                    comandoSQL.Parameters.Add("@NV_RECOMENDACIONES", MySqlDbType.VarChar).Value = pasoDTO.Recomendaciones;
                    comandoSQL.Parameters.Add("@NM_CODIGO", MySqlDbType.Int32).Value = pasoDTO.Codigo;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void eliminar(PasoDTO pasoDTO)
        {
            try
            {
                String sentenciaSQL = "DELETE FROM bsb_paso WHERE NM_CODIGO = @NM_CODIGO";
                using (MySqlCommand comandoSQL = new MySqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Parámetros de la sentencia SQL
                    comandoSQL.Parameters.Add("@NM_CODIGO", MySqlDbType.Int32).Value = pasoDTO.Codigo;
                    comandoSQL.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<PasoDTO> consultar(PasoDTO pasoDTO)
        {
            List<PasoDTO> listaPaso = new List<PasoDTO>();
            try
            {
                String sentenciaSQL = "SELECT P.NM_CODIGO, P.NV_DESCRIPCION, P.NV_ESCALA, P.NV_NIVEL2, P.NV_RECOMENDACIONES " + 
                                      "FROM bsb_paso P " + 
                                      "INNER JOIN bsb_causa C ON C.NM_CODIGO = P.NM_CAUSA WHERE 1";
                using (MySqlCommand comandoSQL = new MySqlCommand(sentenciaSQL, transaccion.Connection, transaccion))
                {
                    // Consultar por codigo
                    if (pasoDTO.Codigo != 0)
                    {
                        sentenciaSQL += " AND P.NM_CODIGO = @NM_CODIGO";
                        comandoSQL.Parameters.Add("@NM_CODIGO", MySqlDbType.Int32).Value = pasoDTO.Codigo;
                    }
                    // Consultar por Causa
                    if (pasoDTO.Causa != null && pasoDTO.Causa.Codigo != 0)
                    {
                        sentenciaSQL += " AND P.NM_CAUSA = @NM_CODIGO_CAUSA";
                        comandoSQL.Parameters.Add("@NM_CODIGO_CAUSA", MySqlDbType.Int32).Value = pasoDTO.Causa.Codigo;
                    }
                    sentenciaSQL += " ORDER BY P.NM_CODIGO";
                    comandoSQL.CommandText = sentenciaSQL;
                    using (MySqlDataReader cursorDatos = comandoSQL.ExecuteReader())
                    {
                        PasoDTO pasoDTOTmp = null;
                        while (cursorDatos.Read())
                        {
                            pasoDTOTmp = new PasoDTO();
                            pasoDTOTmp.Codigo = cursorDatos.GetInt32(0);
                            pasoDTOTmp.Descripcion = cursorDatos.GetString(1);                            
                            pasoDTOTmp.Escala = cursorDatos.GetString(2);
                            pasoDTOTmp.SegundoNivel = cursorDatos.GetString(3);
                            pasoDTOTmp.Recomendaciones = cursorDatos.GetString(4);
                            listaPaso.Add(pasoDTOTmp);
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return listaPaso;
        }

    }
}