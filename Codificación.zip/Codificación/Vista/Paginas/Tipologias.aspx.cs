﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DTO;
using Modelo.Delegador;
using Transversal;

namespace Vista.Paginas
{
    public partial class Tipologias : System.Web.UI.Page
    {

        // Definir clases que se requieren para ejecución de la página
        ProductoDelegador productoDelegador = new ProductoDelegador();
        TipologiaDelegador tipologiaDelegador = new TipologiaDelegador();

        protected void Page_Load(object sender, EventArgs e)
        {
            // Ejecutar al cargar la página por primera vez
            if (!IsPostBack)
            {
                // Mostrar Productos
                mostrarProductos();
            }
        }

        // Mostrar Productos
        private void mostrarProductos()
        {
            List<ProductoDTO> listaProductos = productoDelegador.consultar(new ProductoDTO());
            var productos = from p in listaProductos
                            select new
                            {
                                codigo = p.Codigo,
                                nombre = p.Nombre
                            };
            ddlProducto.DataSource = productos.ToList();
            ddlProducto.DataBind();
            ListItem item = new ListItem("Seleccione", "");
            ddlProducto.Items.Insert(0, item);
        }

        // Evento Click del botón Consultar
        protected void btConsultar_Click(object sender, EventArgs e)
        {
            mostrarTipologias();
        }

        // Mostrar Tipologias
        private void mostrarTipologias()
        {
            TipologiaDTO tipologiaDTO = new TipologiaDTO();
            tipologiaDTO.Nombre = tbNombre.Text;
            if (ddlProducto.SelectedValue != "")
            {
                ProductoDTO productoDTO = new ProductoDTO();
                productoDTO.Codigo = int.Parse(ddlProducto.SelectedValue);
                tipologiaDTO.Producto = productoDTO;
            }
            List<TipologiaDTO> listaTipologias = tipologiaDelegador.consultar(tipologiaDTO);
            var tipologias = from p in listaTipologias
                            select new
                            {
                                codigo = p.Codigo,
                                producto = p.Producto.Nombre,
                                nombre = p.Nombre,
                                estado = Constantes.Estado[p.Estado]
                            };
            gvTipologias.DataSource = tipologias.ToList();
            gvTipologias.DataBind();
            gvTipologias.Visible = true;
        }

        // Evento Click del botón Guardar
        protected void btGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                TipologiaDTO tipologiaDTO = new TipologiaDTO();
                tipologiaDTO.Nombre = tbNombre.Text;
                ProductoDTO productoDTO = new ProductoDTO();
                productoDTO.Codigo = int.Parse(ddlProducto.SelectedValue);
                tipologiaDTO.Producto = productoDTO;
                tipologiaDTO.Estado = int.Parse(ddlEstado.SelectedValue);
                // Actualizar 
                if (hfCodigo.Value != "")
                {
                    tipologiaDTO.Codigo = int.Parse(hfCodigo.Value);
                    tipologiaDelegador.actualizar(tipologiaDTO);
                }
                // Guardar
                else
                {   
                    tipologiaDelegador.crear(tipologiaDTO);
                }
                limpiarCampos();
                gvTipologias.Visible = false;
                ClientScript.RegisterStartupScript(this.GetType(), "mensaje", "mensaje('Tipología guardada correctamente');", true);
            }
            catch (Exception exc)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('Error al guardar');", true);
            }
        }

        // Paginación
        protected void gvTipologias_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvTipologias.PageIndex = e.NewPageIndex;
            mostrarTipologias();
        }

        // Opciones
        protected void gvTipologias_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int index = Convert.ToInt32(e.CommandArgument);
            // Editar 
            if (e.CommandName.Equals("editar"))
            {
                hfCodigo.Value = gvTipologias.DataKeys[index].Value.ToString();
                TipologiaDTO tipologiaDTO = new TipologiaDTO();
                tipologiaDTO.Codigo = int.Parse(hfCodigo.Value);
                tipologiaDTO = tipologiaDelegador.consultar(tipologiaDTO)[0];
                tbNombre.Text = tipologiaDTO.Nombre;
                ddlProducto.SelectedValue = tipologiaDTO.Producto.Codigo.ToString();
                ddlEstado.SelectedValue = tipologiaDTO.Estado.ToString();
            }
            // Eliminar
            else if (e.CommandName.Equals("eliminar"))
            {
                hfCodigo.Value = gvTipologias.DataKeys[index].Value.ToString();
                mpeEliminar.Enabled = true;
                mpeEliminar.Show();
            }
        }

        // Evento Click del botón Confirmar eliminar
        protected void btDelete_Click(object sender, EventArgs e)
        {
            try
            {
                TipologiaDTO tipologiaDTO = new TipologiaDTO();
                tipologiaDTO.Codigo = int.Parse(hfCodigo.Value);
                tipologiaDelegador.eliminar(tipologiaDTO);
                gvTipologias.Visible = false;
                ClientScript.RegisterStartupScript(this.GetType(), "mensaje", "mensaje('Tipología eliminada correctamente');", true);
            }
            catch (Exception exc)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "advertencia", "advertencia('No se puede eliminar esta Tipología porque tiene causas asociadas');", true);
            }
            finally
            {
                limpiarCampos();
            }
        }

        // Evento Click del botón Cancelar eliminar
        protected void btCancelarEliminar_Click(object sender, EventArgs e)
        {
            limpiarCampos();
        }

        // Limpiar Campos
        private void limpiarCampos()
        {
            tbNombre.Text = ddlProducto.SelectedValue = ddlEstado.SelectedValue = hfCodigo.Value = "";
            mpeEliminar.Enabled = gvTipologias.Visible = false;
            mpeEliminar.Hide();
        }

        // Evento Click botón Cancelar
        protected void btCancelar_Click(object sender, EventArgs e)
        {
            limpiarCampos();
        }

    }
}