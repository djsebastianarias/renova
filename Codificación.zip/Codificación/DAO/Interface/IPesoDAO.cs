﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidad;

namespace DAO.Interface
{
    public interface IPesoDAO
    {

        void crear(PesoDTO pesoDTO);

        void actualizar(PesoDTO pesoDTO);

        void eliminar(PesoDTO pesoDTO);

        List<PesoDTO> consultar(PesoDTO pesoDTO);
        List<PesoDTO> reporteMensual(PesoDTO pesoDTO);

    }
}